package com.simple.notepad

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider

class MainActivity : AppCompatActivity() {
    private lateinit var vm: NoteViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        vm = ViewModelProvider(this)[NoteViewModel::class.java]

        findViewById<Button>(R.id.btnAdd).setOnClickListener {
            startActivity(Intent(this, AddNoteActivity::class.java))
        }
    }
}
