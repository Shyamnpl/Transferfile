package com.simple.notepad

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider

class AddNoteActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        val vm = ViewModelProvider(this)[NoteViewModel::class.java]
        val title = findViewById<EditText>(R.id.title)
        val content = findViewById<EditText>(R.id.content)

        findViewById<Button>(R.id.save).setOnClickListener {
            vm.insert(Note(title = title.text.toString(), content = content.text.toString()))
            finish()
        }
    }
}
