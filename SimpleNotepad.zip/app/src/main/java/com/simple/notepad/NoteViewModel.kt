package com.simple.notepad

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class NoteViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = NoteDatabase.get(application).noteDao()
    val notes = dao.getAll()

    fun insert(note: Note) = viewModelScope.launch {
        dao.insert(note)
    }

    fun delete(note: Note) = viewModelScope.launch {
        dao.delete(note)
    }
}
